%stackedplot(RIGHTGLOVEFingerTap);

Fs = 128;
lowpass(Index,15,fs);

% run cleaning data first.
% data is expected to be normalized and segmented
Fs = 128;   %sample rate
L = size(RIGHTGLOVEFingerTap,1);    %sample length
NH = size(RIGHTGLOVEFingerTap,2); %number of healthy sets
%NP = size(RIGHTGLOVEFingerTap,2); %number of pd sets
T = 1/Fs;   %sample period
t = [0:T:(L-1)*T]'; %time bins
n = 2^nextpow2(L); %for zero padding
f = 0:(Fs/n):(Fs/2-Fs/n);%Fs*(0:(L/2))/L; %frequency bins
dim = 2; %signal along columns

plot(f,t) 
title('Fast fouriure transform in frequency domain')
xlabel('f (Hz)')
ylabel('|P1(f)|')
% features to extract are:
% - peak analysis (freq) : perform fft and identify the dominent frequency
% - pulse metrics : rise time, fall time, and settling time
% - spectral measurements : signal power, bandwidth, mean frequency, median
% frequency
% - peak analysis (time) : max peak, min peak, mean peak, variance in peaks